#include "chesssquaredialog.h"
#include "ui_chesssquaredialog.h"

ChessSquareDialog::ChessSquareDialog(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::ChessSquareDialog)
{
    ui->setupUi(this);
}

ChessSquareDialog::~ChessSquareDialog()
{
    delete ui;
}

bool ChessSquareDialog::isEmpty()
{
    return ui->prazno->isChecked();
}

int ChessSquareDialog::getType()
{
    return ui->tip->currentIndex();
}

int ChessSquareDialog::getColor()
{
    return ui->boja->currentIndex();
}
