#include "mainwindow.h"
#include "ui_mainwindow.h"


MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
{
    ui->setupUi(this);
    chessDocu= &ui->centralwidget->getDoc();
    connect(chessDocu, SIGNAL(chessDataChanged()),this,SLOT(repaint()));
}

MainWindow::~MainWindow()
{
    delete ui;
}







void MainWindow::on_actionLoad_Chessboard_triggered()
{
    QString fileName;
    fileName= QFileDialog::getOpenFileName(this,tr("Text files (*.txt)"));
    chessDocu->load(fileName);
}


void MainWindow::on_actionSave_Chessboard_triggered()
{
    QString fileName;
    fileName= QFileDialog::getSaveFileName(this,tr("Text files (*.txt)"));
    chessDocu->save(fileName);

}

