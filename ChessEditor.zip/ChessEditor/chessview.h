#ifndef CHESSVIEW_H
#define CHESSVIEW_H

#include <QWidget>
#include <QPainter>
#include <chessdoc.h>
#include <QMouseEvent>


class ChessView : public QWidget
{
    Q_OBJECT
public:
    explicit ChessView(QWidget *parent = nullptr);
    void drawChessboard(QPainter* p);
    ChessDoc& getDoc(){ return docu; }
signals:

protected:
    void paintEvent(QPaintEvent *e);
    void mouseDoubleClickEvent(QMouseEvent *e) override;
private:
   ChessDoc docu;

};

#endif // CHESSVIEW_H

