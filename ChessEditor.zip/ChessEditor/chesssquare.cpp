#include "chesssquare.h"

ChessSquare::ChessSquare()
{

}

ChessSquare::ChessSquare(bool ie, int sc, int ft, int fc)
{
    isEmpty= ie;
    squareColor= sc;
    figureType= ft;
    figureColor= fc;

}

ChessSquare::ChessSquare(bool ie, int sc)
{
   isEmpty= ie;
   squareColor= sc;
}
