#include "chessview.h"

ChessView::ChessView(QWidget *parent) : QWidget(parent)
{

}

void ChessView::drawChessboard(QPainter *p)
{

    int dimenzija= 300;
    for(int i=0;i<8;i++){
        for(int j=0;j<8;j++){
    p->drawImage(QRect(j * dimenzija, i * dimenzija,dimenzija,dimenzija),
                 QImage(":/resursni/bitmapa.png"),
                 QRect(docu.vratiJedan(i,j)->vratiFigureType()*200,docu.vratiJedan(i,j)->vratiFigureColor()*200,200,200));
            }
    }
}

void ChessView::paintEvent(QPaintEvent *e)
{
    QPainter* p= new QPainter(this);
    p->setRenderHint(QPainter::Antialiasing);
    p->setBackground(Qt::gray);
    p->setWindow(0,0,300,300);

    drawChessboard(p);
}

void ChessView::mouseDoubleClickEvent(QMouseEvent *e)
{
    if(e->button()==Qt::LeftButton){
        int x= e->x();
        int y= e->y();


    }

}


