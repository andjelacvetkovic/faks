#include "chessdoc.h"

ChessDoc::ChessDoc(QObject *parent) : QObject(parent)
{
    mat= new ChessSquare*[8];
    for(int i=0;i<8;i++){
        mat[i]=new ChessSquare[8];
    }

}



void ChessDoc::load(QString file)
{
    QFile f(file);

    if (!f.open(QIODevice::ReadOnly))
        qFatal("Could not open file");

    QString str= f.readAll();
    QStringList parts= str.split(",");
    int i=0;
    int broj=0;
    int l=0,k=0;
    ChessSquare *a;
    while(i<64){
        broj=broj%2;
        if(parts[i].compare("-")!=0){
            if(parts[i].left(1)=="B"){
                if(parts[i].right(1).compare("K")==0){
                  a= new ChessSquare(false,broj,0,0);
                    mat[l][k]= *a;
                    broj++;

                }
                else if(parts[i].right(1).compare("Q")==0){
                    a= new ChessSquare(false,broj,1,0);
                      mat[l][k]= *a;
                      broj++;
                  }
                else if(parts[i].right(1).compare("R")==0){
                    a= new ChessSquare(false,broj,4,0);
                      mat[l][k]= *a;
                      broj++;
                  }
                else if(parts[i].right(1).compare("B")==0){
                  a= new ChessSquare(false,broj,2,0);
                    mat[l][k]= *a;
                    broj++;
                }
                else if(parts[i].right(1).compare("N")==0){
                    a= new ChessSquare(false,broj,3,0);
                      mat[l][k]= *a;
                      broj++;
                  }
                else {
                    a= new ChessSquare(false,broj,5,0);
                      mat[l][k]= *a;
                      broj++;

                }
                if(k<8){
                    k++;
                }
                else{
                    l++;
                    k=0;
                }
            }
            else {
                if(parts[i].right(1).compare("K")==0){
                  a= new ChessSquare(false,broj,0,1);
                    mat[l][k]= *a;
                    broj++;
                }
                else if(parts[i].right(1).compare("Q")==0){
                    a= new ChessSquare(false,broj,1,1);
                      mat[l][k]= *a;
                      broj++;
                  }
                else if(parts[i].right(1).compare("R")==0){
                    a= new ChessSquare(false,broj,4,1);
                      mat[l][k]= *a;
                      broj++;
                  }
                else if(parts[i].right(1).compare("B")==0){
                  a= new ChessSquare(false,broj,2,1);
                    mat[l][k]= *a;
                    broj++;
                }
                else if(parts[i].right(1).compare("N")==0){
                    a= new ChessSquare(false,broj,3,1);
                      mat[l][k]= *a;
                      broj++;
                  }
                else {
                    a= new ChessSquare(false,broj,5,1);
                      mat[l][k]= *a;
                      broj++;
                }
                if(k<8){
                    k++;
                }
                else{
                    l++;
                    k=0;
                }
            }
        }
        else{
            a= new ChessSquare(true,broj);
            mat[l][k]= *a;
            if(k<8){
                k++;
            }
            else{
                l++;
                k=0;
            }
        }
    }
    f.close();
    emit chessDataChanged();
}

void ChessDoc::save(QString file)
{
    QString a;
    QFile f(file);
    if(!f.open(QIODevice::WriteOnly))
        qFatal("Could not open file");

    int i=0;
    while(i<8){
        int j=0;
        while(j<8){
            if(mat[i][j].vratiEmpty()==false){
                if(mat[i][j].vratiFigureColor()==0){
                    if(mat[i][j].vratiFigureType()==0){
                        if(j==7){
                            a+="BK\r\n";
                        }
                        else {
                            a+="BK,";
                        }
                    }
                    else if(mat[i][j].vratiFigureType()==1){
                        if(j==7){
                            a+="BQ\r\n";
                        }
                        else{
                            a+="BQ,";
                        }
                    }
                    else if(mat[i][j].vratiFigureType()==2){
                        if(j==7){
                            a+="BB\r\n";
                        }
                        else{
                            a+="BB,";
                        }
                    }
                    else if(mat[i][j].vratiFigureType()==3){
                        if(j==7){
                            a+="BN\r\n";
                        }
                        else{
                            a+="BN,";
                        }
                    }
                    else if(mat[i][j].vratiFigureType()==4){
                        if(j==7){
                            a+="BR\r\n";
                        }
                        else{
                            a+="BR,";
                        }
                    }
                    else{
                        if(j==7){
                            a+="BP\r\n";
                        }
                        else{
                            a+="BP,";
                        }
                    }

                }
                else {
                    if(mat[i][j].vratiFigureType()==0){
                        if(j==7){
                            a+="WK\r\n";
                        }
                        else {
                            a+="WK,";
                        }
                    }
                    else if(mat[i][j].vratiFigureType()==1){
                        if(j==7){
                            a+="WQ\r\n";
                        }
                        else{
                            a+="WQ,";
                        }
                    }
                    else if(mat[i][j].vratiFigureType()==2){
                        if(j==7){
                            a+="WB\r\n";
                        }
                        else{
                            a+="WB,";
                        }
                    }
                    else if(mat[i][j].vratiFigureType()==3){
                        if(j==7){
                            a+="WN\r\n";
                        }
                        else{
                            a+="WN,";
                        }
                    }
                    else if(mat[i][j].vratiFigureType()==4){
                        if(j==7){
                            a+="WR\r\n";
                        }
                        else{
                            a+="WR,";
                        }
                    }
                    else{
                        if(j==7){
                            a+="WP\r\n";
                        }
                        else{
                            a+="WP,";
                        }
                    }

                }
                }
            else{
                if(j==7){
                    a+="-\r\n";
                }
                else{
                    a+="-,";
                }
            }
            j++;
            }
         i++;
        }
            f.write(a.toUtf8());
            emit chessDataChanged();
    }

