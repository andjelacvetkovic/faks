#ifndef CHESSSQUAREDIALOG_H
#define CHESSSQUAREDIALOG_H

#include <QDialog>

namespace Ui {
class ChessSquareDialog;
}

class ChessSquareDialog : public QDialog
{
    Q_OBJECT

public:
    explicit ChessSquareDialog(QWidget *parent = nullptr);
    ~ChessSquareDialog();
    bool isEmpty();
    int getType();
    int getColor();
private:
    Ui::ChessSquareDialog *ui;
};

#endif // CHESSSQUAREDIALOG_H
