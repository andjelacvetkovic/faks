#ifndef CHESSDOC_H
#define CHESSDOC_H

#include <QObject>
#include <chesssquare.h>
#include <QFile>

class ChessDoc : public QObject
{
    Q_OBJECT
public:
    explicit ChessDoc(QObject *parent = nullptr);
    void load(QString file);
    void save(QString file);
    ChessSquare* vratiJedan(int i, int j){ return mat[i][j]; }

signals:
    void chessDataChanged();
private:
  ChessSquare **mat;
};

#endif // CHESSDOC_H
