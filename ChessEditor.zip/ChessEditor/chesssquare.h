#ifndef CHESSSQUARE_H
#define CHESSSQUARE_H


class ChessSquare
{
public:
    ChessSquare();
    ChessSquare(bool ie, int sc, int ft, int fc);
    ChessSquare(bool ie, int sc);
    bool vratiEmpty(){ return isEmpty; }
    int vratiSquareColor(){ return squareColor; }
    int vratiFigureType(){ return figureType; }
    int vratiFigureColor(){ return figureColor; }
private:
    int squareColor; // 0-crno, 1-belo
    bool isEmpty; //da li je polje prazno
    int figureType; // 0-kralj, 1-kraljica, 2-lovac, 3-konj, 4-top, 5-pion
    int figureColor; // 0-crna, 1-bela

};

#endif // CHESSSQUARE_H
